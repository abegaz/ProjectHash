package edu.ung.mccb.csci.csci6450.model;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Model {

    private String generateHash(String plaintext, MessageDigest messageDigest)
    {
        String generatedHashedPassword = null;
        byte[] bytes = messageDigest.digest();
        StringBuilder sBuilder = new StringBuilder();
        for(int i=0; i< bytes.length ;i++){
            sBuilder.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
        }
        generatedHashedPassword = sBuilder.toString();
        return generatedHashedPassword;
    }


    public String generatePasswordHash(String passwordToHash){

        String generatedHashedPassword = null;
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
            messageDigest.update(passwordToHash.getBytes(StandardCharsets.UTF_8));
            generatedHashedPassword = generateHash(passwordToHash, messageDigest);
            String text = "The hash code for a plaintext password: "+ passwordToHash + " is "+ generatedHashedPassword;
            BufferedWriter out = new BufferedWriter(new FileWriter("hashcodes", true));
            out.write(text+ "\n");
            out.close();
        }
        catch (NoSuchAlgorithmException e){
            e.printStackTrace();
        }
        catch (IOException e)
        {
            System.out.println("Exception ");
        }
        return generatedHashedPassword;
    }

    public String generatePasswordSaltedHash(String passwordToHash, String salt){
        String generatedHashedPassword = null;
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
            messageDigest.update(passwordToHash.getBytes(StandardCharsets.UTF_8));
            messageDigest.update(salt.getBytes(StandardCharsets.UTF_8));
            generatedHashedPassword= generateHash(passwordToHash, messageDigest);
            String text = "The salted hash code for a plaintext password:  "+ passwordToHash + " is "+ generatedHashedPassword;
            BufferedWriter out = new BufferedWriter(new FileWriter("hashcodes", true));
            out.write(text + "\n");
            out.close();
        }
        catch (NoSuchAlgorithmException e){
            e.printStackTrace();
        }
        catch (IOException e)
        {
            System.out.println("Exception ");
        }
        return generatedHashedPassword;
    }
}
