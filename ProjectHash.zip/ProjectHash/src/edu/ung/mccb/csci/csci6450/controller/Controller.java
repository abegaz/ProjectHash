package edu.ung.mccb.csci.csci6450.controller;
import edu.ung.mccb.csci.csci6450.model.Model;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class Controller {
    @FXML
    TextField email, username, password;

    public void touchLogin(ActionEvent actionEvent) {

        Model model = new  Model();
        String hashPassword = model.generatePasswordHash(password.getText());
        String hashAndSaltedPassword = model.generatePasswordSaltedHash(password.getText(), "CSCi6450@UNG");
        System.out.println("Hash code for the plaintext " + password.getText() + " is " + hashPassword);
        System.out.println("Salted hash code for the plaintext " + password.getText() + " is " + hashAndSaltedPassword);

    }
}
